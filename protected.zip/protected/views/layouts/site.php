<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en-US">
    <head>
        <title>Swift Transportation Careers - joinswift.com</title>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <meta name="description" content="Swift Transportation Careers Site">
        <meta name="application-name" content="Swift Transportation Careers">
        <link rel="shortcut icon" href="i/icons/favicon.ico">
        <link rel="stylesheet" type="text/css" href="c/styles.css">
        <link rel="stylesheet" type="text/css" href="c/print.css" media="print">
        <link rel="stylesheet" type="text/css" href="c/parallaxSlider.css">
        <script type="text/javascript" src="j/jquery-1.7.min.js"></script>
        <script type="text/javascript" src="j/global.js"></script>
        <script type="text/javascript" src="j/hover_main.js"></script>
        <script type="text/javascript" src="j/parallaxSlider.js"></script>
        <script type="text/javascript">

            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-28547381-1']);
            _gaq.push(['_trackPageview']);

            (function () {
                var ga = document.createElement('script');
                ga.type = 'text/javascript';
                ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(ga, s);
            })();

        </script>
        <!-- Start Quantcast Tag -->

        <script type="text/javascript">

            var _qevents = _qevents || [];



            (function () {

                var elem = document.createElement('script');

                elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";

                elem.async = true;

                elem.type = "text/javascript";

                var scpt = document.getElementsByTagName('script')[0];

                scpt.parentNode.insertBefore(elem, scpt);

            })();



            _qevents.push(
                    {qacct: "p-0zTGw55mJDG6B", labels: "_fp.event.Homepage"}

            );

        </script>

    <noscript>

        <img src="//pixel.quantserve.com/pixel/p-0zTGw55mJDG6B.gif?labels=_fp.event.Homepage" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/>

    </noscript>

    <!-- End Quantcast tag -->
</head>
<body id="home">
    <?php
    echo $content;
    ?>
    <script type="text/javascript" src="j/jquery.easing.1.3.js"></script>
    <script type="text/javascript">
            $(function () {
                var $pxs_container = $('#pxs_container');
                $pxs_container.parallaxSlider();
            });
    </script>
    <script type="text/javascript">
        adroll_adv_id = "HOFAZKOTHVCFXESQQFQVXE";
        adroll_pix_id = "PKGQ4UC4XNA3RNCOFJJO4O";
        (function () {
            var oldonload = window.onload;
            window.onload = function () {
                __adroll_loaded = true;
                var scr = document.createElement("script");
                var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
                scr.setAttribute('async', 'true');
                scr.type = "text/javascript";
                scr.src = host + "/j/roundtrip.js";
                ((document.getElementsByTagName('head') || [null])[0] ||
                        document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
                if (oldonload) {
                    oldonload()
                }
            };
        }());
    </script>

    <!-- Google Code for Retargeting JoinSwift.com visitors -->
    <script type="text/javascript">
        /* <![CDATA[ */
        var google_conversion_id = 1029165656;
        var google_conversion_label = "TO0CCJzCmQkQ2KTf6gM";
        var google_custom_params = window.google_tag_params;
        var google_remarketing_only = true;
        /* ]]> */
    </script>
    <script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
    </script>
    <noscript>
        <div style="display:inline;">
            <img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1029165656/?value=1.000000&amp;label=TO0CCJzCmQkQ2KTf6gM&amp;guid=ON&amp;script=0"/>
        </div>
    </noscript>

</body>
</html>