<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en-US">
    <head>
    </head>

<script>
    window.location.href = '/manager/login';
</script>
</body>
</html>