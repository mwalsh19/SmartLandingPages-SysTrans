<?php
$basePath = Yii::app()->getBaseUrl(true) . '/';
$ClienteScript = Yii::app()->clientScript;
$ClienteScript->registerCssFile('http://fast.fonts.net/cssapi/fdbec8c1-bb62-4a79-9b2e-74758d1444a9.css');
$ClienteScript->registerCssFile($basePath . 'vendor/swifttrans/css/styles.css');
?>

<div class="thankyou4">
    <h2>THANK YOU</h2>
    <hr>

    <p><strong>A recruiter will be contacting you within 24-48 hours.</strong> <br><br>
        We look forward to speaking with you and getting you started with Swift.
    </p>
</div>