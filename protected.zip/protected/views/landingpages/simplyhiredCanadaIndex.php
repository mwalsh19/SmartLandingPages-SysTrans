
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Index File</title>
</head>

<body bgcolor="#ffffff" text="#000000">
        <table border="1" cellpadding="5">

<tbody>

        <tr>

                <td><strong>Company</strong></td>

                <td><strong>Job Title</strong></td>

                <td><strong>Description</strong></td>

                <td><strong>Location</strong></td>

        </tr>




<tr>

                <td>Canada</td>

                <td></td>
                
                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/1">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/2">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/3">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/4">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/5">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/6">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/7">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/8">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/9">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/10">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/11">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/calgary/alberta/12">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/13">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/14">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/15">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/16">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/17">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/18">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/19">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/20">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/21">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/22">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/23">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/24">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/edmonton/alberta/25">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/26">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/27">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/28">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/29">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/30">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/31">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/32">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/33">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/34">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/35">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/36">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/37">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/red_deer/alberta/38">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/39">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/40">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/41">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/42">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/43">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/44">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/45">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/46">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/47">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/48">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/49">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/50">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/lethbridge/alberta/51">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/52">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/53">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/54">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/55">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/56">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/57">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/58">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/59">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/60">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/61">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/62">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/63">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/vancouver/british_columbia/64">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/65">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/66">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/67">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/68">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/69">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/70">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/71">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/72">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/73">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/74">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/75">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/76">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/abbotsford/british_columbia/77">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/78">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/79">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/80">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/81">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/82">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/83">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/84">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/85">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/86">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/87">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/88">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/89">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/chilliwack/british_columbia/90">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/91">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/92">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/93">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/94">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/95">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/96">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/97">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/98">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/99">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/100">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/101">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/102">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/richmond/british_columbia/103">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/104">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/105">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/106">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/107">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/108">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/109">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/110">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/111">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/112">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/113">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/114">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/115">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/surrey/british_columbia/116">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/117">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/118">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/119">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/120">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/121">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/122">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/123">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/124">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/125">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/126">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/127">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/128">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/hope/british_columbia/129">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/130">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/131">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/132">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/133">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/134">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/135">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/136">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/137">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/138">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/139">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/140">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/141">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/toronto/ontario/142">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/143">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/144">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/145">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/146">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/147">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/148">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/149">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/150">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/151">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/152">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/153">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/154">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/kingston/ontario/155">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/156">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/157">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/158">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/159">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/160">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/161">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/162">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/163">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/164">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/165">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/166">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/167">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cornwall/ontario/168">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/169">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/170">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/171">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/172">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/173">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/174">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/175">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/176">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/177">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/178">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/179">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/180">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/mississauga/ontario/181">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/182">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/183">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/184">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/185">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/186">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/187">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/188">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/189">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/190">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/191">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/192">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/193">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/cambridge/ontario/194">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/195">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/196">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/197">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/198">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/199">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/200">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/201">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/202">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/203">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/204">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/205">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/206">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/montreal/quebec/207">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/208">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/209">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/210">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 872-3004!</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/211">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/212">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/213">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/214">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/215">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/216">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/217">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/218">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/219">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/simplyhired/drummondville/quebec/220">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 872-3004</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr>




                        </tbody>

</table>

</html>