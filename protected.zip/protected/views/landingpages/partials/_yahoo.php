<script type="text/javascript">
    if (!window.mstag)
        mstag = {loadTag: function () {
            },
            time: (new Date()).getTime()};
</script>
<script id="mstag_tops" type="text/javascript" src="//flex.msn.com/mstag/site/3a2fbe54-0aeb-4ec4-977d-3eb8ac1e36f8/mstag.js">
</script>
<script type="text/javascript">
    mstag.loadTag("analytics", {dedup: "1", domainId: "3111688", type: "1", actionid: "245280"})
</script>
<noscript>
<iframe src="//flex.msn.com/mstag/tag/3a2fbe54-0aeb-4ec4-977d-3eb8ac1e36f8/analytics.html?dedup=1&domainId=3111688&type=1&actionid=245280" frameborder="0" scrolling="no" width="1" height="1" style="visibility:hidden;display:none">
</iframe>
</noscript>