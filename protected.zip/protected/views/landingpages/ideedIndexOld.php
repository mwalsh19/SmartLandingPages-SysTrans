

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Index File</title>
</head>

<body bgcolor="#ffffff" text="#000000">
 <table border="1" cellpadding="5">

<tbody>

<tr>

<td><strong>Company</strong></td>

<td><strong>Job Title</strong></td>

<td><strong>Description</strong></td>

<td><strong>Location</strong></td>

</tr>

</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Arizona?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Arizona</td>

</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=California?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>California</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Colorado?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Colorado</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Nevada?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Nevada</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Texas?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Texas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Idaho?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Idaho</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Utah?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Utah</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Oregon?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Oregon</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Washington?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Washington</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Pennsylvania?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Pennsylvania</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Ohio?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Ohio</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Mississippi?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Mississippi</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Alabama?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Alabama</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Illinois?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Illinois</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Wisconsin?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Wisconsin</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Indiana?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Indiana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Virginia?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Virginia</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Kansas?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Kansas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Missouri?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Missouri</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Kentucky?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Kentucky</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Michigan?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Michigan</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Minnesota?date=Apr15//">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Minnesota</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Tennessee?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Tennessee</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Louisiana?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Louisiana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/indeed/students-lp?location=Oklahoma?date=Apr15/">Academy Truck Driver Trainees - Scholarships for Veterans</a></td>

<td>Need a Class A CDL? Swift Academies offer PTDI certified courses and “Best-In-Class” training. Now offering scholarships to U.S. Veterans, National Guard and Reserves.</td>

<td>Oklahoma</td>



</tr><tr>


<td><strong>Experienced</strong></td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/ohio-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Ohio</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/alabama-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Alabama</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/georgia-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Georgia</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/new-york-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>New York</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/louisiana-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Louisiana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/texas-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Texas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/michigan-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Michigan</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/arizona-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Arizona</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/arkansas-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Arkansas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/california-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>California</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/montana-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Montana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/mississippi-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Mississippi</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/illinois-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Illinois</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/indiana-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Indiana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/idaho-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Idaho</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/colorado-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Colorado</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/wyoming-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Wyoming</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/iowa-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Iowa</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/tennessee-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Tennessee</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/missouri-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Missouri</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/connecticut-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Connecticut</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/delaware-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Delaware</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/minnesota-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Minnesota</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/oklahoma-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Oklahoma</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/oregon-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Oregon</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/kansas-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Kansas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/kentucky-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Kentucky</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/nevada-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Nevada</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/nebraska-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Nebraska</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/massachusetts-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Massachusetts</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/new-jersey-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>New Jersey</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/new-mexico-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>New Mexico</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/pennsylvania-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Pennsylvania</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/rhode-island-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Rhode Island</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/utah-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Utah</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/virginia-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Virginia</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://www.joinswift.com/landing-pages/experienced/indeed/washington-dc-lp">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Washington DC</td>

</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/experienced/indeed/wisconsin-lp-2/">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Wisconsin</td>

</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/experienced/indeed/laredo-lp/">Experienced Truck Drivers</a></td>

<td>Flatbed, Regional, Intermodal and Over the Road opportunities are ready and available NOW.</td>

<td>Laredo, TX</td>

</tr><tr>

<td><strong>Recent Grads</strong></td>

</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=alabama-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Alabama</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=arizona-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Arizona</td>




</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=arkansas-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Arkansas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=california-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>California</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=colorado-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Colorado</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=connecticut-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Connecticut</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=delaware-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Delaware</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=georgia-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Georgia</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=idaho-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Idaho</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=illinois-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Illinois</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=indiana-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Indiana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=iowa-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Iowa</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=kansas-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Kansas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=kentucky-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Kentucky</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=massachusetts-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Massachusetts</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=minnesota-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Minnesota</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=mississippi-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Mississippi</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=missouri-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Missouri</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=montana-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Montana</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=nebraska-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Nebraska</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=nevada-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Nevada</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=new-jersey-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>New Jersey</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=new-mexico-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>New Mexico</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=new-york-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>New York</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=ohio-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Ohio</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=oklahoma-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Oklahoma</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=oregon-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Oregon</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=pennsylvania-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Pennsylvania</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=rhode-island-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Rhode Island</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=tennessee-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Tennessee</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=texas-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Texas</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=utah-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Utah</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=virginia-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Virginia</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=washington-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Washington</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href="http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=/washington-dc-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Washington DC</td>



</tr><tr>

<td>Swift Transportation</td>

<td><a href=" http://joinswift.com/landing-pages/recent-grad/indeed/lp-2/?location=wyoming-lp">Recent CDL Grads - Truck Drivers Needed</a></td>

<td>NEW PERFORMANCE PAY INCENTIVES for Flatbed, Regional & OTR Drivers.</td>

<td>Wyoming</td>
</tr>

<!------------ DEDICATED Cabela------------>
<tr><td><strong>Dedicated Cabela</strong></td></tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/AZ">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Arizona</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/NM">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>New Mexico</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/UT">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Utah</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/TX">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Texas</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/CO">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Colorado</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/OK">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Oklahoma</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/NE">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Nebraska</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/KS">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Kansas</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/WI">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Wisconsin</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/IL">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Illinois</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/NV">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Nevada</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/OH">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Ohio</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/WY">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Wyoming</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/Indeed/Dedicated/C/MT">Experienced CDL Drivers Team Regional Dedicated Runs Call (866) 363-0440</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path drivers can meet head-on. To be eligible, you must have at least 6 months recent commercial driving experience. Consistent freight means a consistent paycheck. Limited Availablity. Call Now! </td>
<td>Montana</td>
</tr>

<!------------ DEDICATED Main------------>
<tr><td><strong>Dedicated Main</strong></td></tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Class A CDL Truck Drivers Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Rome, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Truck Drivers Dedicated Runs! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Utica, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Earn $1000 Sign On Bonus! Dedicated Runs for Experienced Truck Drivers! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Lee, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Experienced CDL Drivers Dedicated Route, $1000 Sign On Bonus! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Blossvale, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Experienced Truck Drivers, Class A CDL License, $1000 Sign On Bonus! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Syracuse, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Join the Swift Family! Earn $1000 Sign On Bonus! Experienced CDL Truck Drivers Dedicated Run </a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Hamilton, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Class A CDL Truck Drivers Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Pulaski, New York</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Truck Drivers Dedicated Runs! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Camroden, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Earn $1000 Sign On Bonus! Dedicated Runs for Experienced Truck Drivers! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Floyd, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Experienced CDL Drivers Dedicated Route, $1000 Sign On Bonus! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Vernon, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Experienced Truck Drivers, Class A CDL License, $1000 Sign On Bonus! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Sherrill, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Join the Swift Family! Earn $1000 Sign On Bonus! Experienced CDL Truck Drivers Dedicated Run </a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Verona, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Class A CDL Truck Drivers Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Oneida, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Truck Drivers Dedicated Runs! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Durhamville, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Earn $1000 Sign On Bonus! Dedicated Runs for Experienced Truck Drivers! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Oriskany, New York</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Experienced CDL Drivers Dedicated Route, $1000 Sign On Bonus! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Hillsboro, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Experienced Truck Drivers, Class A CDL License, $1000 Sign On Bonus! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Clark Mills, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Join the Swift Family! Earn $1000 Sign On Bonus! Experienced CDL Truck Drivers Dedicated Run </a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Kirkland, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Class A CDL Truck Drivers Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Westmoreland, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">$1000 Sign On Bonus! Experienced Truck Drivers Dedicated Runs! Call (866) 892-1975</a></td>
<td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Walesville, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/LosLunas/NM">Experienced CDL Truck Drivers Wanted for Exciting Dedicated Routes, Los Lunas, NM! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>
<td>Los Lunas, New Mexico</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/LosLunas/NM">Experienced CDL Truck Drivers Wanted for Exciting Dedicated Routes, Los Lunas, NM! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>
<td>Moberly, Missouri</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Monroe/GA">Experienced CDL Truck Drivers Wanted for Exciting Dedicated Routes, Monroe, GA! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>
<td>Monroe, Georgia</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/FD/StGeorge/UT">Experienced CDL Truck Drivers Wanted for Exciting Dedicated Routes, St. George, UT! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>
<td>St. George, Utah</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/DT/Stockton/CA">Experienced CDL Truck Drivers Wanted for Exciting Dedicated Routes, Stockton, CA! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>
<td>Stockton, California</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Willows/CA">Hiring Experienced and Recent CDL Grad Truck Drivers for Dedicated Routes, Willows, CA! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path for this exciting Dedicated Route! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>
<td>Willows, California</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Arcadia/FL">Hiring Experienced CDL Truck Drivers for Dedicated Routes, Arcadia, FL! Call Now (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>
<td>Arcadia, Florida</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Brundidge/AL">Hiring Experienced and Recent CDL Grad Truck Drivers for Dedicated Routes, Brundidge, AL! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>
<td>Brundidge, Alabama</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Cleburne/TX">Hiring Experienced CDL Truck Drivers for Dedicated Routes, Cleburne, TX! Call Now (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>
<td>Cleburne, Texas</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Corinne/UT">Hiring Experienced CDL Truck Drivers for Dedicated Routes, Corrine, UT! Call Now (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>
<td>Corinne, Utah</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Grandview/WA">Hiring Experienced and Recent CDL Grad Truck Drivers for Dedicated Routes, Grandview, WA! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>
<td>Grandview, Washington</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/MacClenny/FL">Hiring Experienced CDL Truck Drivers for Dedicated Routes, MacClenny, FL! Call Now (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>MacClenny, Florida</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Temple/TX">Hiring Experienced and Recent CDL Grad Truck Drivers Wanted for Dedicated Routes, Temple, TX! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Temple, Texas</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Winterhaven/FL">Hiring Experienced CDL Truck Drivers for Dedicated Routes, Winterhaven, FL! Call Now (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Winterhaven, Florida</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Harrisonville/MO">Experienced CDL Truck Drivers, Earn More with Dedicated Refrigerated Routes Harrisonville, MO! Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Refrigerated Route has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Harrisonville, Missouri</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Johnstown/NY">Experienced CDL Truck Drivers, Earn More with Dedicated Refrigerated Routes Johnstown, NY! Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Refrigerated Route has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Johnstown, New York</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Opelika/AL">Hiring Experienced and Recent CDL Grad Truck Drivers for Dedicated Refrigerated Routes, Opelika, AL! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Refrigerated Route has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Opelika, Alabama</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Pottsville/PA">Hiring Experienced and Recent CDL Grad Truck Drivers for Dedicated Refrigerated Routes, Pottsville, PA! Call (866) 892-1975</a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Refrigerated Route has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Pottsville, Pennsylvania</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Roberts/LA">Experienced CDL Truck Drivers, Earn More with Dedicated Refrigerated Routes Roberts, LA! Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Refrigerated Route has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Roberts, Louisiana</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/intermodal/Indeed/LomaLinda/CA">Get More Home Time & Earn Great Pay! Experienced CDL Drivers for Intermodal Runs Loma Linda, CA. Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Intermodal Run has Great Pay, Consistent Freight, Full Benefits, Paid Vacation, Daily Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Loma Linda, California</td>
</tr>
<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/intermodal/Indeed/Montebello/CA">Get More Home Time & Earn Great Pay! Experienced CDL Drivers for Intermodal Runs Montebello, CA. Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Intermodal Run has Great Pay, Consistent Freight, Full Benefits, Paid Vacation, Daily Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Montebello, California</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/intermodal/indeed/Chicago/IL">Get More Home Time & Earn Great Pay! Experienced CDL Drivers for Intermodal Runs Chicago, IL. Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Intermodal Run (Chicago, IL) has Great Pay, Consistent Freight, Full Benefits, Paid Vacation, Daily Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Chicago, Illinois</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/intermodal/indeed/Jonestown/PA">Get More Home Time & Earn Great Pay! Experienced CDL Drivers for Intermodal Runs Jonestown, PA. Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Intermodal Run (Jonestown, PA) has Great Pay, Consistent Freight, Full Benefits, Paid Vacation, Daily Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Jonestown, Pennsylvania</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/intermodal/indeed/Milwaukee/WI">Get More Home Time & Earn Great Pay! Experienced CDL Drivers for Intermodal Runs Milwaukee, WI. Call (866) 892-1975 </a></td>
<td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Intermodal Run (Milwaukee, WI) has Great Pay, Consistent Freight, Full Benefits, Paid Vacation, Daily Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>
<td>Milwaukee, Wisconsin</td>
</tr>
<!-- 
FLATBED 
<tr><td><strong>Flatbed</strong></td></tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=washington?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Washington</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=oregon?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Oregon</td>
</tr>

<tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=california?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>California</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=nevada?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Nevada</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=utah?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Utah</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=arizona?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Arizona</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=louisiana?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Louisiana</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=indiana?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Indiana</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=pennsylvania?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Pennsylvania</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=west-virginia?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>West Virginia</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=virginia?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Virginia</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=maryland?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Maryland</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=new-jersey?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>New Jersey</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=north-carolina?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>North Carolina</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=south-carolina?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>South Carolina</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=georgia?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Georgia</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=dallas-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Dallas, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=san-antonio-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>San Antonio, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=austin-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Austin, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=houston-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Houston, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=fort-worth-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Fort Worth, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=corpus-christi-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Corpus Christi, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=galveston-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Galveston, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=waco-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Waco, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=plano-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Plano, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=carrollton-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Carrollton, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=wichita-falls-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Wichita Falls, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=alibene-tx?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Abilene, TX</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=albuquerque-nm?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Albuquerque, NM</td>
</tr><tr>

<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=chicago-il?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Chicago, IL</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=rockford-il?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Rockford, IL</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=naperville-il?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Naperville, IL</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=joliet-il?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Joliet, IL</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=joliet-il?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Elgin, IL</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=peoria-il?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Peoria, IL</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=madison-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Madison,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=milwaukee-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Milwaukee,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=kenosha-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Kenosha,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=racine-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Racine,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=oshkosh-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Oshkosh,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=appleton-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Appleton,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=green-bay-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Green Bay,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=janesville-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Janesville,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=waukesha-wi?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Waukesha,  WI</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=columbus-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Columbus, OH</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=cincinnati-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Cincinnati, OH</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=dayton-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Dayton, OH</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=lima-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Lima, OH</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=springfield-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Springfield, OH</td>
</tr><tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=chillicothe-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Chillicothe, OH</td>
</tr>
<td>Swift Transportation</td>
<td><a href="http://joinswift.com/landing-pages/flatbed/indeed-flatbed-lp?location=cleveland-oh?date=july14/">Flatbed Truck Driver – Class A CDL </a></td>
<td>Great Flatbed opportunities at Swift Transportation, for Class A CDL Truck Drivers. Get consistent miles, pay and home time.</td>
<td>Cleveland, OH</td>
</tr>
 -->

</tbody>

</table>

&nbsp;</html>

    
