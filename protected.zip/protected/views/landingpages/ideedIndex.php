<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Index File</title>
</head>

<body bgcolor="#ffffff" text="#000000">
 <table border="1" cellpadding="5">

<tbody>

<tr>

<td><strong>Company</strong></td>

<td><strong>Category</strong></td>

<td><strong>Job Title</strong></td>

<td><strong>Description</strong></td>

<td><strong>Location</strong></td>

</tr>



<tr>

                <td>Students</td>

                <td></td>
                
                <td></td>

                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/alabama/1">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/alabama/2">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/alabama/3">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/alabama/4">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arizona/5">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arizona/6">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arizona/7">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arizona/8">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arkansas/9">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arkansas/10">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arkansas/11">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/arkansas/12">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/california/13">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/california/14">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/california/15">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/california/16">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/colorado/17">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/colorado/18">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/colorado/19">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/colorado/20">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/connecticut/21">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CONNECTICUT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/connecticut/22">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CONNECTICUT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/connecticut/23">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CONNECTICUT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/connecticut/24">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CONNECTICUT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/delaware/25">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>DELAWARE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/georgia/26">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/georgia/27">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/georgia/28">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/georgia/29">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/idaho/30">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/idaho/31">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/idaho/32">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/idaho/33">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/illinois/34">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/illinois/35">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/illinois/36">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/illinois/37">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/indiana/38">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/indiana/39">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/indiana/40">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/indiana/41">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/iowa/42">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/iowa/43">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/iowa/44">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/iowa/45">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kansas/46">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kansas/47">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kansas/48">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kansas/49">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kentucky/50">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kentucky/51">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kentucky/52">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/kentucky/53">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/louisiana/54">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/louisiana/55">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/louisiana/56">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/louisiana/57">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/maryland/58">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MARYLAND</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/maryland/59">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MARYLAND</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/maryland/60">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MARYLAND</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/maryland/61">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MARYLAND</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/massachusetts/62">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/massachusetts/63">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/massachusetts/64">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/massachusetts/65">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/michigan/66">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/michigan/67">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/michigan/68">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/michigan/69">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/minnesota/70">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/minnesota/71">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/minnesota/72">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/minnesota/73">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/mississippi/74">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/mississippi/75">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/mississippi/76">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/mississippi/77">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/missouri/78">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/missouri/79">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/missouri/80">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/missouri/81">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/montana/82">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/montana/83">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/montana/84">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/montana/85">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nebraska/86">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nebraska/87">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nebraska/88">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nebraska/89">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nevada/90">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nevada/91">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nevada/92">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/nevada/93">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_jersey/94">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW JERSEY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_jersey/95">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW JERSEY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_jersey/96">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW JERSEY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_jersey/97">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW JERSEY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_mexico/98">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_mexico/99">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_mexico/100">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_mexico/101">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_york/102">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_york/103">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_york/104">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/new_york/105">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_carolina/106">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_carolina/107">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_carolina/108">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_carolina/109">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_dakota/110">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_dakota/111">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_dakota/112">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/north_dakota/113">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/ohio/114">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/ohio/115">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/ohio/116">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/ohio/117">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oklahoma/118">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oklahoma/119">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oklahoma/120">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oklahoma/121">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oregon/122">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oregon/123">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oregon/124">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/oregon/125">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/pennsylvania/126">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/pennsylvania/127">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/pennsylvania/128">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/pennsylvania/129">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/rhode_island/130">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>RHODE ISLAND</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_carolina/131">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_carolina/132">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_carolina/133">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_dakota/134">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_dakota/135">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_dakota/136">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/south_dakota/137">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/tennessee/138">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/tennessee/139">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/tennessee/140">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/tennessee/141">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/texas/142">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/texas/143">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/texas/144">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/texas/145">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/utah/146">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/utah/147">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/utah/148">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/utah/149">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/vermont/150">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VERMONT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/vermont/151">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VERMONT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/vermont/152">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VERMONT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/vermont/153">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VERMONT</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/virginia/154">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/virginia/155">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/virginia/156">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/virginia/157">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/washington/158">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/washington/159">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/washington/160">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/washington/161">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/west_virginia/162">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/west_virginia/163">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/west_virginia/164">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/west_virginia/165">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wisconsin/166">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wisconsin/167">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wisconsin/168">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wisconsin/169">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wyoming/170">Start your Truck Driver Career in less than 1 year! Student Drivers, Call Swift (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wyoming/171">Transition to Trucking Career in 23 weeks! Student Truck Drivers. Entry-Level. Swift trains you! Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wyoming/172">Entry Level Student Truck Driver. Paid CDL Training for CDL-A Graduates. Call (866) 246-1337</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Student / Trainee Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/indeed/students-lp/wyoming/173">Entry Level, Full-Time Student Truck Driver. Swift trains you, mentors you, & hires you! Call (866) 246-1337!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WYOMING</td>

                </tr>

                <tr>

                <td>New Road</td>

                <td></td>
                
                <td></td>

                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/alabama/1">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/alabama/2">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/alabama/3">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/arizona/4">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/arizona/5">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/arizona/6">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/arkansas/7">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/arkansas/8">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/arkansas/9">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/california/10">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/california/11">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/california/12">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/colorado/13">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/colorado/14">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/colorado/15">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/georgia/16">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/georgia/17">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/georgia/18">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/idaho/19">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/idaho/20">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/idaho/21">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/illinois/22">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/illinois/23">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/illinois/24">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/indiana/25">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/indiana/26">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/indiana/27">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/iowa/28">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/iowa/29">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/iowa/30">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/kansas/31">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/kansas/32">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/kansas/33">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/kentucky/34">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/kentucky/35">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/kentucky/36">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/louisiana/37">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/louisiana/38">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/louisiana/39">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/massachusetts/40">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/massachusetts/41">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/massachusetts/42">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/michigan/43">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/michigan/44">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/michigan/45">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/minnesota/46">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/minnesota/47">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/minnesota/48">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/mississippi/49">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/mississippi/50">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/mississippi/51">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/missouri/52">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/missouri/53">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/missouri/54">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/montana/55">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/montana/56">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/montana/57">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/nebraska/58">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/nebraska/59">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/nebraska/60">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/nevada/61">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/nevada/62">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/nevada/63">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/new_mexico/64">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/new_mexico/65">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/new_mexico/66">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/new_york/67">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/new_york/68">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/new_york/69">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/north_carolina/70">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/north_carolina/71">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/north_carolina/72">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/north_dakota/73">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/north_dakota/74">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/north_dakota/75">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/ohio/76">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/ohio/77">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/ohio/78">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/oklahoma/79">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/oklahoma/80">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/oklahoma/81">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/oregon/82">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/oregon/83">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/oregon/84">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/pennsylvania/85">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/pennsylvania/86">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/pennsylvania/87">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/south_carolina/88">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/south_carolina/89">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/south_carolina/90">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/south_dakota/91">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/south_dakota/92">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/south_dakota/93">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/tennessee/94">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/tennessee/95">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/tennessee/96">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/texas/97">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/texas/98">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/texas/99">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/utah/100">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/utah/101">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/utah/102">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/virginia/103">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/virginia/104">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/virginia/105">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/washington/106">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/washington/107">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/washington/108">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/west_virginia/109">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/west_virginia/110">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/west_virginia/111">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wisconsin/112">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wisconsin/113">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wisconsin/114">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wyoming/115">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wyoming/116">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wyoming/117">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/lewiston/idaho/118">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewiston, IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/lewiston/idaho/119">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Lewiston, IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/lewiston/idaho/120">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Lewiston, IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/anaconda/montana/121">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Anaconda, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/anaconda/montana/122">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Anaconda, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/anaconda/montana/123">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Anaconda, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/belgrade/montana/124">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Belgrade, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/belgrade/montana/125">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Belgrade, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/belgrade/montana/126">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Belgrade, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/billings/montana/127">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Billings, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/billings/montana/128">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Billings, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/billings/montana/129">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Billings, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/bozeman/montana/130">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bozeman, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/bozeman/montana/131">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Bozeman, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/bozeman/montana/132">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Bozeman, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/columbia_falls/montana/133">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Columbia Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/columbia_falls/montana/134">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Columbia Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/columbia_falls/montana/135">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Columbia Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/culbertson/montana/136">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/culbertson/montana/137">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/culbertson/montana/138">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/dillon/montana/139">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/dillon/montana/140">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/dillon/montana/141">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fairview/montana/142">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fairview/montana/143">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fairview/montana/144">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/glendive/montana/145">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/glendive/montana/146">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/glendive/montana/147">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/glendive/montana/148">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/great_falls/montana/149">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Great Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/great_falls/montana/150">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Great Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/great_falls/montana/151">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Great Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/hamilton/montana/152">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Hamilton, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/hamilton/montana/153">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Hamilton, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/hamilton/montana/154">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hamilton, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/hardin/montana/155">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Hardin, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/hardin/montana/156">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Hardin, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/hardin/montana/157">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hardin, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/havre/montana/158">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Havre, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/havre/montana/159">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Havre, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/havre/montana/160">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Havre, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/helena/montana/161">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Helena, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/helena/montana/162">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Helena, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/helena/montana/163">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Helena, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/laurel/montana/164">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Laurel, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/laurel/montana/165">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Laurel, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/laurel/montana/166">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Laurel, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/lewistown/montana/167">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Lewistown, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/lewistown/montana/168">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewistown, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/livingston/montana/169">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Livingston, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/livingston/montana/170">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Livingston, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/livingston/montana/171">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Livingston, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/miles_city/montana/172">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Miles City, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/miles_city/montana/173">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Miles City, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/miles_city/montana/174">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Miles City, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/missoula/montana/175">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Missoula, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/missoula/montana/176">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Missoula, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/missoula/montana/177">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Missoula, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/polson/montana/178">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Polson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/polson/montana/179">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Polson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/polson/montana/180">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Polson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/sidney/montana/181">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/sidney/montana/182">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/sidney/montana/183">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/whitefish/montana/184">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Whitefish, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/whitefish/montana/185">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Whitefish, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/whitefish/montana/186">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Whitefish, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/bismarck/north_dakota/187">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/bismarck/north_dakota/188">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/bismarck/north_dakota/189">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/dickinson/north_dakota/190">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dickinson, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/dickinson/north_dakota/191">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Dickinson, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/dickinson/north_dakota/192">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Dickinson, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fairview/north_dakota/193">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fairview/north_dakota/194">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Fairview, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fairview/north_dakota/195">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Fairview, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fargo/north_dakota/196">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fargo/north_dakota/197">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/fargo/north_dakota/198">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/grand_forks/north_dakota/199">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Grand Forks, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/grand_forks/north_dakota/200">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Grand Forks, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/grand_forks/north_dakota/201">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Grand Forks, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/jamestown/north_dakota/202">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Jamestown, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/jamestown/north_dakota/203">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Jamestown, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/jamestown/north_dakota/204">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Jamestown, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/mandan/north_dakota/205">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Mandan, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/mandan/north_dakota/206">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Mandan, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/mandan/north_dakota/207">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Mandan, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/minot/north_dakota/208">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Minot, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/minot/north_dakota/209">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Minot, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/minot/north_dakota/210">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Minot, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wahpeton/north_dakota/211">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Wahpeton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wahpeton/north_dakota/212">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Wahpeton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/wahpeton/north_dakota/213">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Wahpeton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/west_fargo/north_dakota/214">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>West Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/west_fargo/north_dakota/215">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>West Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/west_fargo/north_dakota/216">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>West Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/williston/north_dakota/217">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/williston/north_dakota/218">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/williston/north_dakota/219">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/trenton/north_dakota/220">Transition into Trucking! Swift trains, mentors, & hires you! Student CDL-A Truck Drivers, Call (866) 921-3078</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/trenton/north_dakota/221">Start your new Career in less than 1 year! Student CDL-A Truck Drivers, Full-Time Positions. We train you!</a></td>

                <td>Enroll in Swift Academy! No Money Down. Tutition Reimbursement & Scholarships. Veterans Scholarship Program. Paid CDL Training for Recent CDL Grads. Job Placement with Swift. Earn Great Starting Pay that grows as you drive more miles. Excellent Benefits, Paid Vacation. Call now (866) 246-1337!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>2016: New Road Ahead</td>
                    
                <td><a href="http://joinswift.com/landing-pages/DR/Jan2016NewRoadAhead/General/Indeed/trenton/north_dakota/222">Get a Work/Life Balance. Experienced CDL-A Drivers join Swift in 2016! Call (866) 921-3078</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr>

                <tr>

                <td>Recent Grads</td>

                <td></td>
                
                <td></td>

                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/alabama/1">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/alabama/2">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/alabama/3">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/alabama/4">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/alabama/5">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arizona/6">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arizona/7">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arizona/8">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arizona/9">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arizona/10">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arkansas/11">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arkansas/12">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/arkansas/13">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/california/14">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/california/15">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/california/16">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/colorado/17">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/colorado/18">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/colorado/19">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/georgia/20">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/georgia/21">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/georgia/22">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/idaho/23">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/idaho/24">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/idaho/25">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/illinois/26">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/illinois/27">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/illinois/28">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/indiana/29">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/indiana/30">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/indiana/31">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/iowa/32">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/iowa/33">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/iowa/34">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/kansas/35">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/kansas/36">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/kansas/37">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/kentucky/38">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/kentucky/39">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/kentucky/40">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/louisiana/41">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/louisiana/42">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/louisiana/43">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/massachusetts/44">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/massachusetts/45">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/massachusetts/46">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/michigan/47">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/michigan/48">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/michigan/49">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/minnesota/50">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/minnesota/51">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/minnesota/52">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/mississippi/53">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/mississippi/54">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/mississippi/55">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/missouri/56">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/missouri/57">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/missouri/58">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/montana/59">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/montana/60">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/montana/61">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/nebraska/62">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/nebraska/63">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/nebraska/64">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/nevada/65">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/nevada/66">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/nevada/67">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/new_mexico/68">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/new_mexico/69">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/new_mexico/70">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/new_york/71">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/new_york/72">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/new_york/73">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/north_carolina/74">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/north_carolina/75">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/north_carolina/76">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/north_dakota/77">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/north_dakota/78">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/north_dakota/79">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/ohio/80">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/ohio/81">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/ohio/82">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/oklahoma/83">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/oklahoma/84">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/oklahoma/85">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/oregon/86">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/oregon/87">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/oregon/88">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/pennsylvania/89">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/pennsylvania/90">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/pennsylvania/91">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/south_carolina/92">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/south_carolina/93">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/south_carolina/94">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/south_dakota/95">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/south_dakota/96">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/south_dakota/97">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/tennessee/98">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/tennessee/99">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/tennessee/100">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/texas/101">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/texas/102">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/texas/103">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/utah/104">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/utah/105">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/utah/106">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/virginia/107">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/virginia/108">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/virginia/109">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/washington/110">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/washington/111">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/washington/112">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/west_virginia/113">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/west_virginia/114">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/west_virginia/115">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/wisconsin/116">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/wisconsin/117">Break into the Trucking Industry as a Driver! Paid CDL Training. Full-Time.</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/wisconsin/118">Full-Time Truck Driver. Transition into Trucking! Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/wyoming/119">Entry-Level CDL Truck Driver. Paid CDL Training. Swift trains you, mentors you, & hires you!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/wyoming/120">Entry Level CDL Truck Driver with Paid CDL Training. Job Placement with Swift!</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Recent CDL Grad Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/recentgrad/indeed/wyoming/121">Full-time, Entry Level Swift CDL-A Truck Driver. Paid CDL Training. Call Now (866) 333-8389</a></td>

                <td>Paid CDL Training with a Swift Mentor. Excellent Benefits. Paid Vacation. Work/Life Balance. Regional Truck Driving and Dedicated Opportunities are available. Drive Innovative and Modern Equipment, Haul Consistent Freight, and follow a Career Path you can meet - Call now!</td>

                <td>WYOMING</td>

                </tr>

                <tr>

                <td>Experienced</td>

                <td></td>
                
                <td></td>

                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/alabama/1">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/alabama/2">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/alabama/3">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ALABAMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/arizona/4">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/arizona/5">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/arizona/6">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARIZONA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/arkansas/7">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/arkansas/8">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/arkansas/9">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ARKANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/california/10">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/california/11">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/california/12">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>CALIFORNIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/colorado/13">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/colorado/14">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/colorado/15">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>COLORADO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/georgia/16">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/georgia/17">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/georgia/18">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>GEORGIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/idaho/19">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/idaho/20">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/idaho/21">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/illinois/22">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/illinois/23">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/illinois/24">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>ILLINOIS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/indiana/25">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/indiana/26">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/indiana/27">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>INDIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/iowa/28">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/iowa/29">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/iowa/30">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>IOWA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/kansas/31">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/kansas/32">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/kansas/33">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KANSAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/kentucky/34">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/kentucky/35">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/kentucky/36">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>KENTUCKY</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/louisiana/37">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/louisiana/38">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/louisiana/39">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>LOUISIANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/massachusetts/40">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/massachusetts/41">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/massachusetts/42">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MASSACHUSETTS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/michigan/43">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/michigan/44">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/michigan/45">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MICHIGAN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/minnesota/46">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/minnesota/47">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/minnesota/48">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MINNESOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/mississippi/49">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/mississippi/50">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/mississippi/51">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSISSIPPI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/missouri/52">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/missouri/53">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/missouri/54">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MISSOURI</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/montana/55">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/montana/56">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/montana/57">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/nebraska/58">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/nebraska/59">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/nebraska/60">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEBRASKA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/nevada/61">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/nevada/62">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/nevada/63">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEVADA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/new_mexico/64">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/new_mexico/65">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/new_mexico/66">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW MEXICO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/new_york/67">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/new_york/68">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/new_york/69">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NEW YORK</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/north_carolina/70">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/north_carolina/71">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/north_carolina/72">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/north_dakota/73">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/north_dakota/74">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/north_dakota/75">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/ohio/76">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/ohio/77">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/ohio/78">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OHIO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/oklahoma/79">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/oklahoma/80">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/oklahoma/81">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OKLAHOMA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/oregon/82">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/oregon/83">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/oregon/84">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>OREGON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/pennsylvania/85">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/pennsylvania/86">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/pennsylvania/87">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>PENNSYLVANIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/south_carolina/88">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/south_carolina/89">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/south_carolina/90">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH CAROLINA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/south_dakota/91">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/south_dakota/92">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/south_dakota/93">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>SOUTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/tennessee/94">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/tennessee/95">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/tennessee/96">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TENNESSEE</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/texas/97">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/texas/98">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/texas/99">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>TEXAS</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/utah/100">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/utah/101">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/utah/102">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>UTAH</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/virginia/103">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/virginia/104">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/virginia/105">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/washington/106">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/washington/107">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/washington/108">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WASHINGTON</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/west_virginia/109">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/west_virginia/110">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/west_virginia/111">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WEST VIRGINIA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wisconsin/112">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wisconsin/113">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wisconsin/114">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WISCONSIN</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wyoming/115">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wyoming/116">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wyoming/117">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>WYOMING</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/lewiston/idaho/118">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewiston, IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/lewiston/idaho/119">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewiston, IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/lewiston/idaho/120">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewiston, IDAHO</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/anaconda/montana/121">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Anaconda, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/anaconda/montana/122">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Anaconda, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/anaconda/montana/123">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Anaconda, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/belgrade/montana/124">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Belgrade, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/belgrade/montana/125">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Belgrade, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/belgrade/montana/126">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Belgrade, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/billings/montana/127">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Billings, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/billings/montana/128">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Billings, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/billings/montana/129">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Billings, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bozeman/montana/130">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bozeman, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bozeman/montana/131">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bozeman, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bozeman/montana/132">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bozeman, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/columbia_falls/montana/133">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Columbia Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/columbia_falls/montana/134">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Columbia Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/columbia_falls/montana/135">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Columbia Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/culbertson/montana/136">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/culbertson/montana/137">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/culbertson/montana/138">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/culbertson/montana/139">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Culbertson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dillon/montana/140">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dillon/montana/141">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dillon/montana/142">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dillon/montana/143">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dillon, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/montana/144">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/montana/145">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/montana/146">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/montana/147">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/glendive/montana/148">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/glendive/montana/149">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/glendive/montana/150">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/glendive/montana/151">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Glendive, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/great_falls/montana/152">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Great Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/great_falls/montana/153">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Great Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/great_falls/montana/154">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Great Falls, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/hamilton/montana/155">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hamilton, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/hamilton/montana/156">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hamilton, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/hamilton/montana/157">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hamilton, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/hardin/montana/158">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hardin, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/hardin/montana/159">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hardin, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/hardin/montana/160">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Hardin, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/havre/montana/161">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Havre, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/havre/montana/162">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Havre, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/havre/montana/163">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Havre, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/helena/montana/164">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Helena, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/helena/montana/165">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Helena, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/helena/montana/166">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Helena, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/laurel/montana/167">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Laurel, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/laurel/montana/168">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Laurel, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/laurel/montana/169">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Laurel, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/lewistown/montana/170">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewistown, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/lewistown/montana/171">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewistown, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/lewistown/montana/172">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Lewistown, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/livingston/montana/173">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Livingston, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/livingston/montana/174">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Livingston, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/livingston/montana/175">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Livingston, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/miles_city/montana/176">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Miles City, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/miles_city/montana/177">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Miles City, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/miles_city/montana/178">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Miles City, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/missoula/montana/179">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Missoula, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/missoula/montana/180">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Missoula, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/missoula/montana/181">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Missoula, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/polson/montana/182">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Polson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/polson/montana/183">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Polson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/polson/montana/184">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Polson, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/sidney/montana/185">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/sidney/montana/186">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/sidney/montana/187">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/sidney/montana/188">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Sidney, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/whitefish/montana/189">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Whitefish, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/whitefish/montana/190">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Whitefish, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/whitefish/montana/191">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Whitefish, MONTANA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bismarck/north_dakota/192">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bismarck/north_dakota/193">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bismarck/north_dakota/194">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/bismarck/north_dakota/195">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Bismarck, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dickinson/north_dakota/196">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dickinson, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dickinson/north_dakota/197">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dickinson, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/dickinson/north_dakota/198">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Dickinson, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/north_dakota/199">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/north_dakota/200">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fairview/north_dakota/201">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fairview, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fargo/north_dakota/202">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fargo/north_dakota/203">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/fargo/north_dakota/204">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/grand_forks/north_dakota/205">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Grand Forks, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/grand_forks/north_dakota/206">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Grand Forks, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/grand_forks/north_dakota/207">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Grand Forks, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/jamestown/north_dakota/208">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Jamestown, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/jamestown/north_dakota/209">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Jamestown, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/jamestown/north_dakota/210">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Jamestown, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/mandan/north_dakota/211">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Mandan, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/mandan/north_dakota/212">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Mandan, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/mandan/north_dakota/213">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Mandan, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/minot/north_dakota/214">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Minot, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/minot/north_dakota/215">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Minot, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/minot/north_dakota/216">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Minot, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wahpeton/north_dakota/217">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Wahpeton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wahpeton/north_dakota/218">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Wahpeton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/wahpeton/north_dakota/219">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Wahpeton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/west_fargo/north_dakota/220">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>West Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/west_fargo/north_dakota/221">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>West Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/west_fargo/north_dakota/222">Drive Dry Van Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>West Fargo, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/williston/north_dakota/223">Drive Container Routes for Swift! Experienced CDL Drivers, Full-Time. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/williston/north_dakota/224">Drive Dedicated Routes for Swift! Experienced CDL Drivers, Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/williston/north_dakota/225">Work/Life Balance. Top Pay. Excellent Benefits. Experienced CDL-A Drivers join Swift Now!</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/williston/north_dakota/226">Earn More & Get Home Time! Hiring Experienced CDL Truck Drivers, Dry Van Routes. Call (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Williston, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/trenton/north_dakota/227">Experienced CDL-A Truck Drivers, Full-Time Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/trenton/north_dakota/228">Experienced Intermodal CDL-A Truck Drivers, Full-Time. Call Swift at (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/trenton/north_dakota/229">Experienced CDL-A Truck Drivers for Dedicated Dry Van Routes. Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Experienced Drivers</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced/indeed/trenton/north_dakota/230">Experienced CDL Dedicated Truck Drivers! Call Now (866) 331-9235</a></td>

                <td>Work/Life Balance. Home Time. Top Pay. Excellent Benefits. Career Options. Drive routes for Convention Services, Container, Dedicated, Flatbed, Heavy Haul, Intermodal, Refrigerated and Dry Van. Dedicated, Intermodal, & Regional Opportunities. Call Now!</td>

                <td>Trenton, NORTH DAKOTA</td>

                </tr>

                <tr>

                <td>Dedicated Main</td>

                <td></td>
                
                <td></td>

                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/fd/ny">Earn $1000 Sign-On Bonus! Experienced CDL-A Drivers for Swift Dedicated Routes, Rome, NY.</a></td>

                <td>No Contracts, No Run-Around. Just open road and a career path you can meet head-on. Great Pay, Consistent Freight, Full Benefits, Paid Vacation, a Career Path, and a $1,000 Sign-On Bonus for the first 10 drivers to be hired for this exciting Dedicated Route! Availability is limited. Call now and join the SWIFT Family! Call (866) 892-1975</td>

                <td>Rome, New York</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Moberly/MO">Experienced CDL-A Truck Drivers for Swift Dedicated Routes in Moberly, MO! Call (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>

                <td>Moberly, Missouri</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/FD/StGeorge/UT">Experienced CDL-A Truck Drivers for Swift Dedicated Routes in St. George, UT! Call (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>

                <td>St. George, Utah</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/DT/Stockton/CA">Experienced CDL-A Truck Drivers for Swift Dedicated Routes in Stockton, CA! Call (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path you can meet! Availability is limited. Call (866) 892-1975 now and join the SWIFT Family!</td>

                <td>Stockton, California</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Willows/CA">Experienced CDL-A Truck Drivers for Swift Dedicated Routes in Willows, CA! Call (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. Good Pay, Consistent Freight, Full Benefits, Paid Vacation, and a Career Path for this exciting Dedicated Route! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>

                <td>Willows, California</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Brundidge/AL">Home Time for Experienced CDL-A Truck Drivers. Swift Dedicated Routes in Brundidge, AL! Call (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>

                <td>Brundidge, Alabama</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Corinne/UT">Home Time for Experienced CDL-A Truck Drivers. Swift Dedicated Routes in Corrine, UT! Call Now (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. This Dedicated Run has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now (866) 892-1975 and join the SWIFT Family!</td>

                <td>Corinne, Utah</td>

                </tr><tr>

                <td>Swift Transportation</td>
                    
                <td>Dedicated Campaign</td>
                    
                <td><a href="http://joinswift.com/landing-pages/dedicated/indeed/W/Pottsville/PA">Home Time for Experienced CDL-A Truck Drivers. Swift Dedicated Reefer Routes in Pottsville, PA! Call (866) 892-1975</a></td>

                <td>No Gimmicks, No Contracts, No Run-Around. Just open road and a career path you can meet head-on. When you drive for Swift, you'll be amazed at how far your experience can take you. To be eligible, you must have at least 6 months recent commercial driving experience. If you have less than 6 months, please call for options. We do have openings for Recent Grads with their CDL Class A License. This Dedicated Refrigerated Route has Good Pay, Consistent Freight, Full Benefits, Paid Vacation, Home Time, and a Career Path you can meet! Availability is limited. Call now and join the SWIFT Family!</td>

                <td>Pottsville, Pennsylvania</td>

                </tr>
                
</tbody>

</table>
</html>