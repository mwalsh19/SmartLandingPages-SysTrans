<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Index File</title>
</head>

<body bgcolor="#ffffff" text="#000000">
 <table border="1" cellpadding="5">

<tbody>

<tr>

<td><strong>Company</strong></td>

<td><strong>Job Title</strong></td>

<td><strong>Description</strong></td>

<td><strong>Location</strong></td>

</tr>



<tr>

                <td>Canada</td>

                <td></td>

                <td></td>

                <td></td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/1">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/2">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/3">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/4">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/5">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/6">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/7">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/8">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/9">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/10">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/11">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/12">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/calgary/alberta/13">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Calgary, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/14">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/15">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/16">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/17">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/18">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/19">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/20">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/21">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/22">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/23">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/24">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/25">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/edmonton/alberta/26">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Edmonton, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/27">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/28">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/29">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/30">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/31">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/32">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/33">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/34">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/35">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/36">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/37">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/38">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/red_deer/alberta/39">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Red Deer, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/40">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/41">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/42">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/43">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/44">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/45">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/46">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/47">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/48">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/49">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/50">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/51">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/lethbridge/alberta/52">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Lethbridge, Alberta</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/53">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/54">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/55">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/56">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/57">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/58">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/59">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/60">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/61">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/62">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/63">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/64">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/vancouver/british_columbia/65">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Vancouver, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/66">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/67">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/68">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/69">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/70">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/71">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/72">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/73">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/74">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/75">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/76">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/77">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/abbotsford/british_columbia/78">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Abbotsford, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/79">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/80">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/81">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/82">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/83">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/84">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/85">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/86">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/87">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/88">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/89">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/90">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/chilliwack/british_columbia/91">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Chilliwack, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/92">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/93">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/94">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/95">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/96">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/97">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/98">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/99">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/100">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/101">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/102">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/103">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/richmond/british_columbia/104">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Richmond, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/105">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/106">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/107">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/108">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/109">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/110">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/111">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/112">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/113">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/114">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/115">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/116">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/surrey/british_columbia/117">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Surrey, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/118">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/119">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/120">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/121">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/122">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/123">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/124">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/125">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/126">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/127">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/128">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/129">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/hope/british_columbia/130">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Hope, British Columbia</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/131">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/132">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/133">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/134">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/135">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/136">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/137">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/138">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/139">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/140">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/141">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/142">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/toronto/ontario/143">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Toronto, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/144">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/145">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/146">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/147">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/148">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/149">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/150">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/151">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/152">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/153">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/154">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/155">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/kingston/ontario/156">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Kingston, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/157">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/158">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/159">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/160">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/161">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/162">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/163">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/164">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/165">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/166">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/167">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/168">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cornwall/ontario/169">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cornwall, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/170">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/171">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/172">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/173">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/174">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/175">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/176">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/177">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/178">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/179">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/180">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/181">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/mississauga/ontario/182">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Mississauga, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/183">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/184">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/185">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/186">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/187">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/188">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/189">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/190">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/191">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/192">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/193">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/194">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/cambridge/ontario/195">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Cambridge, Ontario</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/196">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/197">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/198">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/199">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/200">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/201">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/202">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/203">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/204">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/205">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/206">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/207">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/montreal/quebec/208">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Montreal, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/209">Sign On Bonus for Experienced Line-Haul Truck Drivers! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/210">Hiring Experienced Line-Haul Truck Drivers now! Sign On Bonus. Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/211">English & French speaking Experienced Line-Haul Drivers in Demand! Sign On Bonus, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/212">HIRING LINEHAUL EXPERIENCED TRUCK DRIVERS, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/213">Linehaul Experienced Drivers - 50 Cents Per Mile CDN (All Miles), Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/214">Guaranteed Pay Per Week during start- up. Experienced Linehaul Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/215">Great Pay. Excellent Benefits. Sign On Bonus. Linehaul Experienced Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/216">Border Crossing Pay & Sign-On Bonus! Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/217">Work/Life Balance & Excellent Benefits. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/218">Top Pay. Excellent Benefits. Work/Life Balance. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/219">Linehaul Experienced Drivers earn Top Pay & Sign On Bonus! Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/220">Excellent benefits, Great Pay, Sign-On Bonus. Hiring Linehaul Experienced Truck Drivers, Call (866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr><tr>

                <td>Swift Canada</td>
                    
                <td><a href="http://joinswift.com/landing-pages/experienced-canada/indeed/drummondville/quebec/221">Consistent Freight, Work/Life balance. Hiring Linehaul Experienced Truck Drivers, Call ((866) 611-5611</a></td>

                <td>SWIFT Canada supports every driver, every mile, every day. Experience the open road with excellent benefits, great pay, sign-on bonus, paid vacation, consistent freight, work/life balance, and more! Call now to learn more about Swift Canada!</td>

                <td>Drummondville, Quebec</td>

                </tr>



</tbody>

</table>
</html>
