<?php
	$this->renderPartial('_page', array('tel' => '1-855-543-9950'));
?>