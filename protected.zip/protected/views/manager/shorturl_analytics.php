<?php

?>
<section class="content-header clearfix">
    <h1 class="pull-left">
        <span>Manager</span> > <span>Google URL Analytics</span>
    </h1>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-body">
                    
                    <?php echo $table; ?>
                </div>
            </div>
        </div>
    </div>
</section>