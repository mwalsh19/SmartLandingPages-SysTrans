<?php

class MModel extends CActiveRecord {
	
}

