#!/bin/bash
git clone git@bitbucket.org:MauricioTrinidad/yii-swift-landing-pages.git /D/Sites/swift_lp/clone
